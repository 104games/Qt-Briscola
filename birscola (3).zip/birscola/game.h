#ifndef GAME_H
#define GAME_H

#include <QMainWindow>
#include <vector>
#include <iostream>
#include "player.h"
#include "carta.h"
#include<stack>
using namespace std;



namespace Ui {
class game;
}

class game : public QMainWindow
{
    Q_OBJECT

public:
    explicit game(QWidget *parent = nullptr);
    ~game();
    void passa_players(QString nomi, bool bt);
    void riempi_mazzo();
    void stack_mazzo();



private:
    Ui::game *ui;
    vector<Player> giocatori;
    //creazione mazzo vector e mazzo stack


};

#endif // GAME_H
