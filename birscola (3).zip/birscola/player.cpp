
#include "player.h"
#include "carta.h"
#include<stack>
#include <iostream>
using namespace std;
Player::Player(string n, bool i)
{

    carta1 = mazzo.top();
    mazzo.pop();
    carta2 = mazzo.top();
    mazzo.pop();
    carta3 = mazzo.top();
    mazzo.pop();
    nome = n;
    is_bot = i;


}
