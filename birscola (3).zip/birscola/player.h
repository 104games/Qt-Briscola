#ifndef PLAYER_H
#define PLAYER_H
#include <iostream>
#include<stack>
#include<vector>
#include "carta.h"


using namespace std;

class Player
{
public:
    vector<Carta> mazzo_iniziale;
    stack<Carta> mazzo;
    Carta carta1;
    Carta carta2;
    Carta carta3;
    string nome;
    bool is_bot;
    Player(string n, bool bt);
};

#endif // PLAYER_H
