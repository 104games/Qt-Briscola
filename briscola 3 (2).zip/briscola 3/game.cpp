#include "game.h"
#include "player.h"
#include "playercreation.h"
#include "ui_game.h"

#include<vector>
#include<stack>

#include <iostream>
using namespace std;

using namespace std;
game::game(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::game)
{
    ui->setupUi(this);
}

game::~game()
{
    delete ui;
}

Mazzo mazz = Mazzo();

Player::Player(string n, bool i)
{
    carta1 = mazz.mazzo.top();
    mazz.mazzo.pop();
    carta2 = mazz.mazzo.top();
    mazz.mazzo.pop();
    carta3 = mazz.mazzo.top();
    mazz.mazzo.pop();
    nome = n;
    is_bot = i;
}

void Player::pesca_carta(int n){
    if(n==1){
        carta1=mazz.mazzo.top();
        mazz.mazzo.pop();
    }
    if(n==2){
        carta2=mazz.mazzo.top();
        mazz.mazzo.pop();
    }
    if(n==3){
        carta3=mazz.mazzo.top();
        mazz.mazzo.pop();
    }
}


void game::passa_bot(vector<bool> bt){
    bots = bt;
    players = bt.size();
}
void game::passa_nomi(vector<string> n){
    nomi = n;
}

void game::turno(){

    ui->giocatore->setText(QString::fromStdString(nomi[attuale]));
    ui->carta1->setStyleSheet(QString::fromStdString(giocatori[attuale].carta1.texture));
    ui->carta2->setStyleSheet(QString::fromStdString(giocatori[attuale].carta2.texture));
    ui->carta3->setStyleSheet(QString::fromStdString(giocatori[attuale].carta3.texture));


}

void game::start(){
    //QString::fromStdString()

    for(int x=0; x<players; x++){
        Player giocatore = Player(nomi[x],bots[x]);
        giocatori.push_back(giocatore);
        cout << x << endl;
    }
    attuale =0;
    turno();
}


void game::assegna_punti(){
    int max=0;
    for(int x=0; x<tavolo.size();x++){
        cout << tavolo[x].texture << endl;
        if(tavolo[x].seme == tavolo[max].seme){
            if(tavolo[x].num > tavolo[max].num){
                max=x;
            }
        }
        else if(tavolo[x].seme == mazz.briscola.seme){
            if(tavolo[max].seme == mazz.briscola.seme){
                if(tavolo[x].num > tavolo[max].num){
                    max=x;
                }
            }
            else{
                max=x;
            }
        }
    }
    if(max==0 || max==2){
        for(int x=0; x<tavolo.size(); x++){
            punti1+= tavolo[x].punti;
        }

    }
    if(max==1 || max==3){
        for(int x=0; x<tavolo.size(); x++){
            punti2+= tavolo[x].punti;
        }
    }
    cout<< max << endl << punti1 << " " << punti2 << endl;
    tavolo.clear();
}

void game::on_carta1_clicked()
{
    cout << attuale << endl;
    tavolo.push_back(giocatori[attuale].carta1);
    giocatori[attuale].pesca_carta(1);
    attuale++;
    if(attuale==giocatori.size()){
        attuale = 0;
        cout << "reset";
        assegna_punti();
    }
    turno();
}


void game::on_carta2_clicked()
{
    tavolo.push_back(giocatori[attuale].carta2);
    giocatori[attuale].pesca_carta(2);
    attuale++;
    if(attuale==giocatori.size()){
        attuale = 0;
        cout << "reset";
        assegna_punti();
    }
    turno();
}


void game::on_carta3_clicked()
{
    tavolo.push_back(giocatori[attuale].carta3);
    giocatori[attuale].pesca_carta(3);
    attuale++;
    if(attuale==giocatori.size()){
        attuale = 0;
        cout << "reset";
        assegna_punti();
    }
    turno();
}

