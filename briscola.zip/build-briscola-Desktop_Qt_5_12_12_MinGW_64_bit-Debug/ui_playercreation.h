/********************************************************************************
** Form generated from reading UI file 'playercreation.ui'
**
** Created by: Qt User Interface Compiler version 5.12.12
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PLAYERCREATION_H
#define UI_PLAYERCREATION_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_PlayerCreation
{
public:
    QWidget *centralwidget;
    QCheckBox *isBot;
    QTextEdit *titolo;
    QPushButton *pushButton;
    QLineEdit *nome;
    QMenuBar *menubar;
    QMenu *menuPlayer_Creation;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *PlayerCreation)
    {
        if (PlayerCreation->objectName().isEmpty())
            PlayerCreation->setObjectName(QString::fromUtf8("PlayerCreation"));
        PlayerCreation->resize(1317, 607);
        centralwidget = new QWidget(PlayerCreation);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        isBot = new QCheckBox(centralwidget);
        isBot->setObjectName(QString::fromUtf8("isBot"));
        isBot->setGeometry(QRect(830, 180, 91, 41));
        QFont font;
        font.setPointSize(16);
        isBot->setFont(font);
        isBot->setIconSize(QSize(50, 50));
        titolo = new QTextEdit(centralwidget);
        titolo->setObjectName(QString::fromUtf8("titolo"));
        titolo->setGeometry(QRect(290, 20, 611, 111));
        titolo->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 85, 0);"));
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(500, 260, 161, 41));
        pushButton->setFont(font);
        nome = new QLineEdit(centralwidget);
        nome->setObjectName(QString::fromUtf8("nome"));
        nome->setGeometry(QRect(370, 180, 441, 51));
        QFont font1;
        font1.setPointSize(20);
        nome->setFont(font1);
        PlayerCreation->setCentralWidget(centralwidget);
        menubar = new QMenuBar(PlayerCreation);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 1317, 26));
        menuPlayer_Creation = new QMenu(menubar);
        menuPlayer_Creation->setObjectName(QString::fromUtf8("menuPlayer_Creation"));
        PlayerCreation->setMenuBar(menubar);
        statusbar = new QStatusBar(PlayerCreation);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        PlayerCreation->setStatusBar(statusbar);

        menubar->addAction(menuPlayer_Creation->menuAction());

        retranslateUi(PlayerCreation);

        QMetaObject::connectSlotsByName(PlayerCreation);
    } // setupUi

    void retranslateUi(QMainWindow *PlayerCreation)
    {
        PlayerCreation->setWindowTitle(QApplication::translate("PlayerCreation", "MainWindow", nullptr));
        isBot->setText(QApplication::translate("PlayerCreation", "bot", nullptr));
        titolo->setHtml(QApplication::translate("PlayerCreation", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:36pt;\">CREA PERSONAGGIO</span></p></body></html>", nullptr));
        pushButton->setText(QApplication::translate("PlayerCreation", "crea", nullptr));
        nome->setPlaceholderText(QApplication::translate("PlayerCreation", "nome", nullptr));
        menuPlayer_Creation->setTitle(QApplication::translate("PlayerCreation", "Player Creation", nullptr));
    } // retranslateUi

};

namespace Ui {
    class PlayerCreation: public Ui_PlayerCreation {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PLAYERCREATION_H
