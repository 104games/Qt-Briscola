/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.12
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QTextBrowser *titolo;
    QPushButton *mod1;
    QPushButton *mod2;
    QPushButton *mod3;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->setEnabled(true);
        MainWindow->resize(1241, 545);
        QFont font;
        font.setFamily(QString::fromUtf8("System"));
        font.setPointSize(32);
        font.setBold(true);
        MainWindow->setFont(font);
        MainWindow->setStyleSheet(QString::fromUtf8(""));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        titolo = new QTextBrowser(centralwidget);
        titolo->setObjectName(QString::fromUtf8("titolo"));
        titolo->setEnabled(true);
        titolo->setGeometry(QRect(200, 30, 831, 141));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Constantia"));
        font1.setPointSize(48);
        font1.setBold(true);
        titolo->setFont(font1);
        titolo->setMouseTracking(false);
        titolo->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 85, 0);"));
        mod1 = new QPushButton(centralwidget);
        mod1->setObjectName(QString::fromUtf8("mod1"));
        mod1->setGeometry(QRect(350, 310, 131, 41));
        mod2 = new QPushButton(centralwidget);
        mod2->setObjectName(QString::fromUtf8("mod2"));
        mod2->setGeometry(QRect(540, 310, 171, 41));
        mod3 = new QPushButton(centralwidget);
        mod3->setObjectName(QString::fromUtf8("mod3"));
        mod3->setGeometry(QRect(770, 310, 151, 41));
        MainWindow->setCentralWidget(centralwidget);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", nullptr));
        titolo->setHtml(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Constantia'; font-size:48pt; font-weight:700; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:72pt;\">BRISCOLA</span></p></body></html>", nullptr));
        mod1->setText(QApplication::translate("MainWindow", "Plaver VS Player", nullptr));
        mod2->setText(QApplication::translate("MainWindow", "2 Players VS 2 Players", nullptr));
        mod3->setText(QApplication::translate("MainWindow", "5 Players", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
